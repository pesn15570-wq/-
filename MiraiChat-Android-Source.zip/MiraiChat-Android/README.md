# Mirai Chat — Android

แอปแชต AI ส่วนตัวสำหรับ Android ที่มีหน้าตาแบบ dark workspace และปรับแต่งผู้ให้บริการโมเดลได้เอง โปรเจกต์นี้เป็น Android app จริง (WebView UI + Kotlin native bridge) ไม่ใช่แค่เว็บไซต์ที่เปิดผ่านเบราว์เซอร์

## ความสามารถในเวอร์ชันนี้

- หน้ารวมบทสนทนา, ค้นหาแชต, สร้างแชตใหม่ และลบแชต
- หน้าสนทนาแบบสตรีมคำตอบทีละส่วน (เมื่อผู้ให้บริการรองรับ SSE)
- ตั้งค่า API Base URL และ Model ID สำหรับบริการที่รองรับ OpenAI Chat Completions API
- API Key เข้ารหัสด้วย AES-GCM โดยใช้กุญแจที่สร้างและเก็บใน Android Keystore
- ประวัติแชตและการตั้งค่าทั่วไปเก็บไว้ในพื้นที่แอปบนอุปกรณ์
- Dark / Light theme และ System Prompt ที่ปรับเองได้
- ไม่ฝังคีย์ API ลงในซอร์สโค้ดหรือ APK

## วิธี Build APK ผ่าน GitHub Actions

1. สร้าง repository ใหม่บน GitHub
2. แตกไฟล์ ZIP นี้ แล้วอัปโหลด **เนื้อหาทั้งหมด** เข้า repository (ต้องเห็นโฟลเดอร์ `.github/workflows/` ที่ root)
3. ไปที่แท็บ **Actions** แล้วเลือก **Build Android APK**
4. กด **Run workflow** หรือ push ไฟล์ขึ้น branch `main` / `master`
5. เมื่อ workflow สำเร็จ เปิด run ล่าสุด แล้วดาวน์โหลด artifact ชื่อ `mirai-chat-debug-apk`
6. แตก artifact จะได้ `app-debug.apk` นำไปติดตั้งบน Android ได้

Workflow อยู่ที่ `.github/workflows/build.yml` และเรียก Gradle 8.9 + JDK 17 + Android SDK 35 (ใช้รุ่น Android Gradle Plugin 8.7.3 ซึ่งกำหนด Gradle ขั้นต่ำ 8.9)

## วิธีตั้งค่า AI ในแอป

1. เปิด Mirai Chat แล้วกด **ตั้งค่า**
2. ใส่ API Base URL ของผู้ให้บริการ เช่น `https://api.openai.com/v1`
3. ใส่ Model ID ที่บัญชี/ผู้ให้บริการของคุณเปิดให้ใช้งาน เช่น `gpt-4o-mini` (ตัวอย่างนี้ไม่ได้รับประกันว่าบัญชีจะมีสิทธิ์ใช้)
4. วาง API Key แล้วกดบันทึก
5. เริ่มแชตได้เลย

แอปนี้ **ไม่ได้แถม API Key หรือโควตา AI ฟรี** ค่าใช้บริการขึ้นอยู่กับผู้ให้บริการและบัญชีที่นำมาเชื่อมต่อ ตรวจสอบราคาและสิทธิ์การใช้งานจากผู้ให้บริการก่อนใช้

## ข้อกำหนดของ API

- ต้องเป็น HTTPS
- รองรับรูปแบบ `POST /chat/completions` ของ OpenAI Chat Completions API
- รองรับ `Authorization: Bearer <API_KEY>`
- เปิด `stream: true` เพื่อให้แสดงผลแบบทยอยตอบ หาก endpoint ไม่รองรับ streaming แอปจะลองอ่านคำตอบ JSON ปกติ
- Base URL ให้ใส่เป็น root เช่น `https://api.example.com/v1` หรือใส่ endpoint `/chat/completions` มาเต็มก็ได้

## Build ในเครื่อง (ทางเลือก)

ต้องมี JDK 17, Android SDK Platform 35, Build Tools 35.0.0 และ Gradle 8.9 จากนั้นรันที่ root:

```bash
gradle --no-daemon assembleDebug
```

ไฟล์ APK จะอยู่ที่ `app/build/outputs/apk/debug/app-debug.apk`

## ข้อจำกัดที่ควรรู้

- เวอร์ชันนี้รองรับแชตข้อความเป็นหลัก ยังไม่มีแนบรูป/เสียง, voice mode, การล็อกอินหลายบัญชี หรือระบบซิงก์ข้ามอุปกรณ์
- บริการที่มี API format เฉพาะตัวหรือจำเป็นต้องใช้ header เพิ่มเติม อาจต้องปรับ Native bridge ก่อน
- ประวัติแชตเก็บใน local app storage ไม่ได้เข้ารหัสแยกต่างหาก จึงไม่ควรพิมพ์ข้อมูลลับหรือข้อมูลที่ไม่ต้องการให้คนที่เข้าถึงเครื่องเห็น
- API Key ถูกเก็บแบบเข้ารหัสใน Android Keystore แต่เมื่อเรียกใช้งาน คีย์จำเป็นต้องถูกอ่านมาใช้ในหน่วยความจำของแอป
- APK จาก workflow เป็น **debug build** สำหรับติดตั้งทดสอบส่วนตัว ไม่ใช่ release ที่เซ็นด้วยกุญแจประจำตัวสำหรับเผยแพร่บน Play Store

## โครงสร้างหลัก

```text
.
├── .github/workflows/build.yml
├── app/
│   ├── build.gradle.kts
│   └── src/main/
│       ├── AndroidManifest.xml
│       ├── java/com/boom/miraichat/MainActivity.kt
│       ├── res/values/styles.xml
│       └── assets/www/
│           ├── index.html
│           ├── styles.css
│           └── app.js
├── build.gradle.kts
├── settings.gradle.kts
└── gradle.properties
```
