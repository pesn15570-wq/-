# Mirai Chat — Android source package

This ZIP contains the Android project files at the archive root. It intentionally does **not** include `.github/workflows/build.yml`, because the workflow is maintained separately in the GitHub repository.

## Build prerequisites
- JDK 17
- Android SDK Platform 35 and Build Tools 35.0.0
- Gradle 8.7 (the project uses Android Gradle Plugin 8.6.1)

## Important: GitHub Actions extraction path
The repository currently stores this source as a ZIP. The workflow must extract the ZIP into the directory where Gradle is run. Example shell steps (adjust the ZIP filename if needed):

```yaml
- name: Unzip project into workspace root
  run: unzip -o MiraiChat-Phase1-Source.zip -d .

- name: Build debug APK
  run: gradle --no-daemon assembleDebug

- name: Verify APK
  run: test -f app/build/outputs/apk/debug/app-debug.apk

- name: Upload APK artifact
  uses: actions/upload-artifact@v4
  with:
    name: mirai-chat-debug-apk
    path: app/build/outputs/apk/debug/app-debug.apk
```

Do not extract the project into a subfolder and then run Gradle from the repository root. The `settings.gradle.kts` and root `build.gradle.kts` must be in the current working directory when Gradle runs.

## Current capabilities
- Android app with bundled WebView UI
- Chat history and settings UI
- OpenAI-compatible Chat Completions API connection
- API key encrypted with Android Keystore

## Important limitation
This source package does **not yet include a native llama.cpp Android engine**. It is not yet a Local AI/offline Qwen3 app. The Qwen3 GGUF models cannot run just by selecting them until the native engine and its JNI integration are added and tested.
