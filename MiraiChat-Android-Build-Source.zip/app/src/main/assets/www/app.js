(() => {
  'use strict';

  const STORAGE_KEY = 'mirai_chat_state_v1';
  const DEFAULT_STATE = {
    chats: [],
    activeId: null,
    settings: {
      baseUrl: 'https://api.openai.com/v1',
      model: 'gpt-4o-mini',
      systemPrompt: 'คุณคือผู้ช่วย AI ที่เป็นมิตร ช่วยคิด วิเคราะห์ และอธิบายอย่างเป็นขั้นตอน ตอบเป็นภาษาไทยที่เข้าใจง่าย กระชับแต่ครบถ้วน หากไม่แน่ใจให้บอกตรง ๆ'
    },
    theme: 'dark'
  };

  const $ = (id) => document.getElementById(id);
  const ui = {
    sidebar: $('sidebar'), mobileScrim: $('mobileScrim'), historyList: $('historyList'), chatCount: $('chatCount'),
    searchChats: $('searchChats'), topTitle: $('topTitle'), modelLabel: $('modelLabel'), connectionDot: $('connectionDot'),
    welcomeView: $('welcomeView'), messages: $('messages'), messageInput: $('messageInput'), sendBtn: $('sendBtn'),
    settingsModal: $('settingsModal'), baseUrl: $('baseUrl'), modelName: $('modelName'), apiKey: $('apiKey'),
    systemPrompt: $('systemPrompt'), keyStatus: $('keyStatus'), saveMessage: $('saveMessage'), toast: $('toast')
  };

  const cloneDefaultState = () => JSON.parse(JSON.stringify(DEFAULT_STATE));
  let state = loadState();
  let toastTimer = null;
  const pending = new Map();

  function loadState() {
    try {
      const saved = JSON.parse(localStorage.getItem(STORAGE_KEY) || 'null');
      if (!saved || typeof saved !== 'object') return cloneDefaultState();
      return {
        ...cloneDefaultState(),
        ...saved,
        settings: { ...DEFAULT_STATE.settings, ...(saved.settings || {}) },
        chats: Array.isArray(saved.chats) ? saved.chats : []
      };
    } catch (_) {
      return cloneDefaultState();
    }
  }

  function saveState() {
    try { localStorage.setItem(STORAGE_KEY, JSON.stringify(state)); }
    catch (_) { showToast('บันทึกไม่สำเร็จ พื้นที่จัดเก็บอาจเต็ม'); }
  }

  function makeId() { return `${Date.now()}_${Math.random().toString(36).slice(2, 8)}`; }
  function currentChat() { return state.chats.find(chat => chat.id === state.activeId) || null; }
  function formatTime(timestamp) {
    try { return new Intl.DateTimeFormat('th-TH', { hour: '2-digit', minute: '2-digit' }).format(new Date(timestamp)); }
    catch (_) { return ''; }
  }

  function showToast(message) {
    ui.toast.textContent = message;
    ui.toast.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => ui.toast.classList.remove('show'), 2400);
  }

  function applyTheme() {
    document.body.classList.toggle('light', state.theme === 'light');
    $('themeBtn').textContent = state.theme === 'light' ? '☾' : '☼';
  }

  function updateConnectionStatus() {
    const connected = Boolean(window.AndroidBridge && window.AndroidBridge.hasApiKey());
    ui.connectionDot.classList.toggle('connected', connected);
    ui.modelLabel.textContent = connected ? state.settings.model : 'ยังไม่เชื่อมต่อ';
    ui.modelLabel.title = connected ? `โมเดล: ${state.settings.model}` : 'กรุณาตั้งค่า API Key';
    $('composerHint').textContent = connected ? `พร้อมคุยด้วย ${state.settings.model}` : 'ตั้งค่า API Key ก่อนเริ่มใช้งาน';
  }

  function renderSidebar() {
    const query = (ui.searchChats.value || '').trim().toLowerCase();
    const chats = [...state.chats].sort((a, b) => (b.updatedAt || 0) - (a.updatedAt || 0));
    ui.chatCount.textContent = String(state.chats.length);
    ui.historyList.replaceChildren();
    const filtered = chats.filter(chat => !query || (chat.title || '').toLowerCase().includes(query));
    if (!filtered.length) {
      const empty = document.createElement('div');
      empty.className = 'history-empty';
      empty.textContent = query ? 'ไม่พบบทสนทนาที่ค้นหา' : 'ยังไม่มีบทสนทนาใหม่\nเริ่มคุยกับ AI ได้เลย';
      ui.historyList.appendChild(empty);
      return;
    }
    for (const chat of filtered) {
      const button = document.createElement('button');
      button.className = `history-item${chat.id === state.activeId ? ' active' : ''}`;
      button.type = 'button';
      const icon = document.createElement('span');
      icon.className = 'history-icon';
      icon.textContent = '◌';
      const name = document.createElement('span');
      name.className = 'history-name';
      name.textContent = chat.title || 'แชตใหม่';
      const del = document.createElement('span');
      del.className = 'delete-chat';
      del.textContent = '×';
      del.setAttribute('role', 'button');
      del.setAttribute('aria-label', 'ลบบทสนทนา');
      del.addEventListener('click', event => {
        event.stopPropagation();
        deleteChat(chat.id);
      });
      button.append(icon, name, del);
      button.addEventListener('click', () => {
        state.activeId = chat.id;
        saveState();
        renderAll();
        closeSidebar();
      });
      ui.historyList.appendChild(button);
    }
  }

  function escapeHtml(value) {
    return String(value).replace(/[&<>"']/g, char => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[char]));
  }

  function formatMessage(text) {
    // Minimal safe formatting: escape all source text before adding a few visual Markdown patterns.
    let safe = escapeHtml(text || '');
    safe = safe.replace(/```([\s\S]*?)```/g, (_, code) => `<pre><code>${code.trim()}</code></pre>`);
    safe = safe.replace(/`([^`\n]+)`/g, '<code>$1</code>');
    safe = safe.replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>');
    return safe.split('\n').map(line => line || '&nbsp;').join('<br>');
  }

  function makeMessageNode(message) {
    const row = document.createElement('article');
    row.className = `message-row ${message.role === 'user' ? 'user' : 'assistant'}`;
    const avatar = document.createElement('div');
    avatar.className = 'message-avatar';
    avatar.textContent = message.role === 'user' ? 'B' : '✦';

    const body = document.createElement('div');
    body.className = 'message-body';
    const meta = document.createElement('div');
    meta.className = 'message-meta';
    const name = document.createElement('strong');
    name.textContent = message.role === 'user' ? 'คุณ' : 'Mirai AI';
    const time = document.createElement('time');
    time.textContent = formatTime(message.createdAt || Date.now());
    meta.append(name, time);

    const bubble = document.createElement('div');
    bubble.className = 'message-bubble';
    if (message.pending && !message.content) {
      const dots = document.createElement('span');
      dots.className = 'typing-dots';
      dots.innerHTML = '<span></span><span></span><span></span>';
      bubble.appendChild(dots);
    } else {
      bubble.innerHTML = formatMessage(message.content || '');
    }
    body.append(meta, bubble);

    if (message.role === 'assistant' && message.content && !message.pending) {
      const tools = document.createElement('div');
      tools.className = 'message-tools';
      const copy = document.createElement('button');
      copy.className = 'message-tool';
      copy.type = 'button';
      copy.textContent = '▢ คัดลอก';
      copy.addEventListener('click', async () => {
        try {
          await navigator.clipboard.writeText(message.content);
          showToast('คัดลอกข้อความแล้ว');
        } catch (_) { showToast('ไม่สามารถคัดลอกได้'); }
      });
      tools.appendChild(copy);
      body.appendChild(tools);
    }
    row.append(avatar, body);
    return row;
  }

  function renderChat() {
    const chat = currentChat();
    const hasMessages = Boolean(chat && chat.messages && chat.messages.length);
    ui.welcomeView.style.display = hasMessages ? 'none' : 'flex';
    ui.messages.style.display = hasMessages ? 'flex' : 'none';
    ui.messages.replaceChildren();
    ui.topTitle.textContent = chat ? (chat.title || 'แชตใหม่') : 'แชตใหม่';
    if (!hasMessages) return;
    for (const message of chat.messages) ui.messages.appendChild(makeMessageNode(message));
    requestAnimationFrame(() => { ui.chatStage.scrollTop = ui.chatStage.scrollHeight; });
  }

  function renderAll() {
    renderSidebar();
    renderChat();
    updateConnectionStatus();
  }

  function createChat() {
    const chat = { id: makeId(), title: 'แชตใหม่', createdAt: Date.now(), updatedAt: Date.now(), messages: [] };
    state.chats.unshift(chat);
    state.activeId = chat.id;
    saveState();
    renderAll();
    closeSidebar();
    ui.messageInput.focus();
    return chat;
  }

  function deleteChat(id) {
    const chat = state.chats.find(item => item.id === id);
    if (!chat) return;
    if (!window.confirm(`ลบบทสนทนา “${chat.title || 'แชตใหม่'}” ใช่ไหม?`)) return;
    state.chats = state.chats.filter(item => item.id !== id);
    for (const [callbackId, item] of pending.entries()) if (item.chatId === id) pending.delete(callbackId);
    if (state.activeId === id) state.activeId = state.chats[0]?.id || null;
    saveState();
    renderAll();
    showToast('ลบบทสนทนาแล้ว');
  }

  function closeSidebar() {
    ui.sidebar.classList.remove('open');
    ui.mobileScrim.classList.remove('show');
  }

  function openSettings() {
    ui.baseUrl.value = state.settings.baseUrl;
    ui.modelName.value = state.settings.model;
    ui.systemPrompt.value = state.settings.systemPrompt;
    ui.apiKey.value = '';
    ui.apiKey.placeholder = window.AndroidBridge && window.AndroidBridge.hasApiKey()
      ? 'บันทึกคีย์ไว้แล้ว · วางคีย์ใหม่เพื่อเปลี่ยน' : 'วาง API Key ของคุณที่นี่';
    updateKeyStatus();
    ui.saveMessage.textContent = '';
    ui.settingsModal.classList.add('open');
    ui.settingsModal.setAttribute('aria-hidden', 'false');
  }

  function closeSettings() {
    ui.settingsModal.classList.remove('open');
    ui.settingsModal.setAttribute('aria-hidden', 'true');
  }

  function updateKeyStatus() {
    const hasKey = Boolean(window.AndroidBridge && window.AndroidBridge.hasApiKey());
    ui.keyStatus.classList.toggle('saved', hasKey);
    ui.keyStatus.querySelector('span:last-child').textContent = hasKey
      ? 'บันทึก API Key แบบเข้ารหัสแล้ว' : 'ยังไม่ได้ตั้งค่า API Key';
  }

  function saveSettings() {
    const baseUrl = ui.baseUrl.value.trim().replace(/\/+$/, '');
    const model = ui.modelName.value.trim();
    const systemPrompt = ui.systemPrompt.value.trim();
    if (!/^https:\/\//i.test(baseUrl)) {
      showToast('Base URL ต้องขึ้นต้นด้วย https://');
      ui.baseUrl.focus();
      return;
    }
    if (!model) {
      showToast('กรุณาระบุชื่อโมเดล');
      ui.modelName.focus();
      return;
    }
    if (!window.AndroidBridge) {
      showToast('ต้องเปิดแอปบน Android เพื่อบันทึก API Key');
      return;
    }
    const newKey = ui.apiKey.value.trim();
    if (newKey && !window.AndroidBridge.saveApiKey(newKey)) {
      showToast('บันทึก API Key ไม่สำเร็จ');
      return;
    }
    state.settings = { baseUrl, model, systemPrompt: systemPrompt || DEFAULT_STATE.settings.systemPrompt };
    saveState();
    updateConnectionStatus();
    updateKeyStatus();
    ui.apiKey.value = '';
    ui.saveMessage.textContent = 'บันทึกแล้ว ✓';
    showToast('บันทึกการตั้งค่าเรียบร้อย');
    setTimeout(closeSettings, 500);
  }

  function removeKey() {
    if (!window.AndroidBridge) return showToast('เปิดใช้งานผ่านแอป Android เพื่อจัดการ API Key');
    if (!window.confirm('ต้องการลบ API Key ที่บันทึกไว้ในอุปกรณ์นี้หรือไม่?')) return;
    const ok = window.AndroidBridge.saveApiKey('');
    if (ok) {
      updateKeyStatus();
      updateConnectionStatus();
      ui.apiKey.value = '';
      ui.apiKey.placeholder = 'วาง API Key ของคุณที่นี่';
      showToast('ลบ API Key แล้ว');
    } else showToast('ลบ API Key ไม่สำเร็จ');
  }

  function sendMessage(text) {
    const content = (text || ui.messageInput.value).trim();
    if (!content) return;
    if (!window.AndroidBridge) {
      showToast('ระบบ AI ใช้งานได้เมื่อเปิดแอป Android ที่ Build แล้ว');
      return;
    }
    if (!window.AndroidBridge.hasApiKey()) {
      showToast('ตั้งค่า API Key ก่อนใช้งาน');
      openSettings();
      return;
    }

    let chat = currentChat();
    if (!chat) chat = createChat();
    if (chat.messages.some(message => message.pending)) {
      showToast('รอให้ AI ตอบข้อความก่อนนะ');
      return;
    }
    const userMessage = { id: makeId(), role: 'user', content, createdAt: Date.now() };
    chat.messages.push(userMessage);
    if (chat.title === 'แชตใหม่') chat.title = content.replace(/\s+/g, ' ').slice(0, 32) + (content.length > 32 ? '…' : '');
    chat.updatedAt = Date.now();
    const assistantMessage = { id: makeId(), role: 'assistant', content: '', createdAt: Date.now(), pending: true };
    chat.messages.push(assistantMessage);
    ui.messageInput.value = '';
    resizeInput();
    saveState();
    renderAll();

    const messages = [];
    if (state.settings.systemPrompt) messages.push({ role: 'system', content: state.settings.systemPrompt });
    for (const message of chat.messages) {
      if (message.id === assistantMessage.id || message.pending) continue;
      messages.push({ role: message.role, content: message.content });
    }
    const callbackId = makeId();
    pending.set(callbackId, { chatId: chat.id, messageId: assistantMessage.id });
    ui.sendBtn.disabled = true;
    try {
      window.AndroidBridge.streamChat(
        JSON.stringify({ baseUrl: state.settings.baseUrl, model: state.settings.model }),
        JSON.stringify(messages),
        callbackId
      );
    } catch (error) {
      assistantMessage.pending = false;
      assistantMessage.content = `เกิดข้อผิดพลาด: ${error.message || 'ไม่สามารถเริ่มการเชื่อมต่อได้'}`;
      pending.delete(callbackId);
      ui.sendBtn.disabled = false;
      saveState();
      renderAll();
    }
  }

  window.onNativeAIEvent = (callbackId, rawEvent) => {
    let event;
    try { event = JSON.parse(rawEvent); } catch (_) { return; }
    const request = pending.get(callbackId);
    if (!request) return;
    const chat = state.chats.find(item => item.id === request.chatId);
    const message = chat?.messages.find(item => item.id === request.messageId);
    if (!chat || !message) {
      pending.delete(callbackId);
      return;
    }
    if (event.type === 'delta') {
      message.content += event.text || '';
    } else if (event.type === 'done') {
      message.pending = false;
      if (!message.content) message.content = '(โมเดลไม่ได้ส่งข้อความตอบกลับ)';
      pending.delete(callbackId);
      ui.sendBtn.disabled = false;
      chat.updatedAt = Date.now();
    } else if (event.type === 'error') {
      message.pending = false;
      message.content = (message.content ? `${message.content}\n\n` : '') + `⚠️ ${event.message || 'เกิดข้อผิดพลาด'}`;
      pending.delete(callbackId);
      ui.sendBtn.disabled = false;
    }
    saveState();
    renderSidebar();
    if (state.activeId === request.chatId) renderChat();
  };

  function resizeInput() {
    ui.messageInput.style.height = 'auto';
    ui.messageInput.style.height = `${Math.min(ui.messageInput.scrollHeight, 140)}px`;
  }

  // Main controls
  $('newChatBtn').addEventListener('click', createChat);
  $('settingsBtn').addEventListener('click', openSettings);
  $('topSettingsBtn').addEventListener('click', openSettings);
  $('closeSettings').addEventListener('click', closeSettings);
  $('saveSettings').addEventListener('click', saveSettings);
  $('removeKeyBtn').addEventListener('click', removeKey);
  $('themeBtn').addEventListener('click', () => {
    state.theme = state.theme === 'dark' ? 'light' : 'dark';
    saveState(); applyTheme();
  });
  $('openSidebar').addEventListener('click', () => {
    ui.sidebar.classList.add('open');
    ui.mobileScrim.classList.add('show');
  });
  $('closeSidebar').addEventListener('click', closeSidebar);
  ui.mobileScrim.addEventListener('click', closeSidebar);
  ui.searchChats.addEventListener('input', renderSidebar);
  ui.sendBtn.addEventListener('click', () => sendMessage());
  ui.messageInput.addEventListener('input', resizeInput);
  ui.messageInput.addEventListener('keydown', event => {
    if (event.key === 'Enter' && !event.shiftKey) {
      event.preventDefault();
      sendMessage();
    }
  });
  ui.settingsModal.addEventListener('click', event => { if (event.target === ui.settingsModal) closeSettings(); });
  $('toggleKey').addEventListener('click', () => {
    const isPassword = ui.apiKey.type === 'password';
    ui.apiKey.type = isPassword ? 'text' : 'password';
    $('toggleKey').textContent = isPassword ? 'ซ่อน' : 'แสดง';
  });
  document.querySelectorAll('.preset-chip').forEach(button => {
    button.addEventListener('click', () => { ui.modelName.value = button.dataset.model || ''; });
  });
  document.querySelectorAll('.suggestion').forEach(button => {
    button.addEventListener('click', () => sendMessage(button.dataset.prompt || ''));
  });
  document.addEventListener('keydown', event => {
    if (event.key === 'Escape') { closeSettings(); closeSidebar(); }
    if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 'k') {
      event.preventDefault();
      createChat();
    }
  });

  applyTheme();
  renderAll();
})();
