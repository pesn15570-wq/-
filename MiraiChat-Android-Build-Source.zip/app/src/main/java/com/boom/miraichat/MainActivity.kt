package com.boom.miraichat

import android.annotation.SuppressLint
import android.app.Activity
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.util.Base64
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey

class MainActivity : Activity() {
    private lateinit var webView: WebView

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(10, 11, 18)
        window.navigationBarColor = Color.rgb(10, 11, 18)

        webView = WebView(this)
        webView.setBackgroundColor(Color.rgb(10, 11, 18))
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.allowFileAccess = true
        webView.settings.allowContentAccess = false
        webView.settings.javaScriptCanOpenWindowsAutomatically = false
        webView.settings.setSupportMultipleWindows(false)
        webView.webChromeClient = WebChromeClient()
        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                // The JavaScript bridge is exposed only to the bundled app, never to arbitrary websites.
                return request?.url?.scheme != "file"
            }
        }
        webView.addJavascriptInterface(AndroidBridge(this, webView), "AndroidBridge")
        setContentView(webView)
        webView.loadUrl("file:///android_asset/www/index.html")
    }

    override fun onBackPressed() {
        if (::webView.isInitialized && webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }
}

private class AndroidBridge(context: Context, private val webView: WebView) {
    private val secureStore = SecureKeyStore(context.applicationContext)

    @JavascriptInterface
    fun saveApiKey(value: String): Boolean {
        return try {
            if (value.isBlank()) {
                secureStore.clear()
            } else {
                require(value.length <= 4096) { "API Key ยาวเกินไป" }
                secureStore.save(value.trim())
            }
            true
        } catch (_: Exception) {
            false
        }
    }

    @JavascriptInterface
    fun hasApiKey(): Boolean = try { !secureStore.read().isNullOrBlank() } catch (_: Exception) { false }

    @JavascriptInterface
    fun streamChat(configJson: String, messagesJson: String, callbackId: String) {
        Thread {
            var connection: HttpURLConnection? = null
            try {
                val config = JSONObject(configJson)
                val baseUrl = config.optString("baseUrl", "https://api.openai.com/v1").trim().trimEnd('/')
                val model = config.optString("model", "gpt-4o-mini").trim()
                val apiKey = secureStore.read()
                require(!apiKey.isNullOrBlank()) { "ยังไม่ได้ตั้งค่า API Key กรุณาเปิดตั้งค่า" }
                require(model.isNotBlank()) { "กรุณาระบุชื่อโมเดล" }
                val parsedUrl = Uri.parse(baseUrl)
                require(parsedUrl.scheme == "https" && !parsedUrl.host.isNullOrBlank()) {
                    "Base URL ต้องเป็น HTTPS เช่น https://api.openai.com/v1"
                }
                val endpoint = if (baseUrl.endsWith("/chat/completions")) baseUrl else "$baseUrl/chat/completions"

                val requestBody = JSONObject()
                    .put("model", model)
                    .put("stream", true)
                    .put("messages", JSONArray(messagesJson))

                connection = (URL(endpoint).openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = 30_000
                    readTimeout = 120_000
                    doOutput = true
                    setRequestProperty("Authorization", "Bearer $apiKey")
                    setRequestProperty("Content-Type", "application/json; charset=utf-8")
                    setRequestProperty("Accept", "text/event-stream, application/json")
                }
                OutputStreamWriter(connection.outputStream, Charsets.UTF_8).use { it.write(requestBody.toString()) }

                val status = connection.responseCode
                if (status !in 200..299) {
                    val errorText = (connection.errorStream ?: connection.inputStream).bufferedReader().use { it.readText() }
                    val message = try {
                        val root = JSONObject(errorText)
                        root.optJSONObject("error")?.optString("message")?.takeIf { !it.isNullOrBlank() }
                            ?: root.optString("message", "HTTP $status")
                    } catch (_: Exception) { "HTTP $status: ${errorText.take(240)}" }
                    throw IllegalStateException(message)
                }

                var sawSse = false
                val nonSseBody = StringBuilder()
                BufferedReader(InputStreamReader(connection.inputStream, Charsets.UTF_8)).use { reader ->
                    while (true) {
                        val line = reader.readLine() ?: break
                        if (line.startsWith("data:")) {
                            sawSse = true
                            val data = line.removePrefix("data:").trim()
                            if (data == "[DONE]") break
                            if (data.isNotEmpty()) {
                                try {
                                    val root = JSONObject(data)
                                    val choice = root.optJSONArray("choices")?.optJSONObject(0)
                                    val delta = choice?.optJSONObject("delta")
                                    val content = delta?.opt("content")
                                    if (content is String && content.isNotEmpty()) {
                                        emit(callbackId, JSONObject().put("type", "delta").put("text", content))
                                    }
                                } catch (_: Exception) {
                                    // Ignore provider keep-alive or non-JSON SSE lines.
                                }
                            }
                        } else if (!sawSse && line.isNotBlank()) {
                            nonSseBody.append(line)
                        }
                    }
                }

                // A few compatible services ignore stream=true and return one JSON response.
                if (!sawSse && nonSseBody.isNotEmpty()) {
                    val root = JSONObject(nonSseBody.toString())
                    val content = root.optJSONArray("choices")?.optJSONObject(0)
                        ?.optJSONObject("message")?.optString("content", "") ?: ""
                    if (content.isNotEmpty()) emit(callbackId, JSONObject().put("type", "delta").put("text", content))
                }
                emit(callbackId, JSONObject().put("type", "done"))
            } catch (e: Exception) {
                emit(callbackId, JSONObject().put("type", "error").put("message", e.message ?: "เกิดข้อผิดพลาดในการเชื่อมต่อ"))
            } finally {
                connection?.disconnect()
            }
        }.start()
    }

    private fun emit(callbackId: String, event: JSONObject) {
        val id = JSONObject.quote(callbackId)
        val payload = JSONObject.quote(event.toString())
        webView.post { webView.evaluateJavascript("window.onNativeAIEvent && window.onNativeAIEvent($id, $payload)", null) }
    }
}

/** AES/GCM key stored in Android Keystore; only ciphertext is written to app preferences. */
private class SecureKeyStore(context: Context) {
    private val prefs = context.getSharedPreferences("secure_ai_settings", Context.MODE_PRIVATE)
    private val alias = "mirai_chat_api_key_v1"
    private val storeName = "AndroidKeyStore"

    private fun getOrCreateKey(): SecretKey {
        val keyStore = KeyStore.getInstance(storeName).apply { load(null) }
        val existing = keyStore.getKey(alias, null) as? SecretKey
        if (existing != null) return existing
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, storeName)
        generator.init(
            KeyGenParameterSpec.Builder(alias, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setRandomizedEncryptionRequired(true)
                .build()
        )
        return generator.generateKey()
    }

    fun save(value: String) {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, getOrCreateKey())
        val encrypted = cipher.doFinal(value.toByteArray(Charsets.UTF_8))
        val stored = Base64.encodeToString(cipher.iv, Base64.NO_WRAP) + ":" +
            Base64.encodeToString(encrypted, Base64.NO_WRAP)
        prefs.edit().putString("api_key", stored).apply()
    }

    fun read(): String? {
        val stored = prefs.getString("api_key", null) ?: return null
        val parts = stored.split(":", limit = 2)
        require(parts.size == 2) { "ข้อมูล API Key เสียหาย" }
        val iv = Base64.decode(parts[0], Base64.NO_WRAP)
        val ciphertext = Base64.decode(parts[1], Base64.NO_WRAP)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, getOrCreateKey(), javax.crypto.spec.GCMParameterSpec(128, iv))
        return String(cipher.doFinal(ciphertext), Charsets.UTF_8)
    }

    fun clear() {
        prefs.edit().remove("api_key").apply()
    }
}
